# -*- coding: utf-8 -*-
"""
Created on Fri Feb 16 10:42:37 2024

@author: Omkar
"""

from backtesting import Backtest,Strategy
from backtesting.test import GOOG
from backtesting.lib import crossover,plot_heatmaps,resample_apply
import numpy as np
import pandas_ta as ta
import yfinance as yf
import pandas_datareader.data as pdr
yf.pdr_override()
import pandas as pd
import talib
import seaborn as sns
import matplotlib.pyplot as plt

pd.set_option('display.expand_frame_repr', False)
pd.set_option('display.max_columns', None)

class RSI(Strategy):
    
    upper_bound=70
    lower_bound=30
    rsi_window = 14
    
    def init(self):
        self.daily_rsi = self.I(talib.RSI,self.data.Close,self.rsi_window)
        
    
    def next(self):

        price = self.data.Close[-1]

        if crossover(self.daily_rsi,self.upper_bound):
            self.position.close()
        elif crossover(self.lower_bound,self.daily_rsi):
            self.buy(sl = 0.95 * price)
    
def ema_indicator(data):
    
    ema_12 = ta.ema(close = data.Close.s,length=12)
    ema_24 = ta.ema(close = data.Close.s,length=24)
    ema_55 = ta.ema(close = data.Close.s,length = 55)

    combined_df = pd.concat([ema_12, ema_24, ema_55], axis=1)

    return(combined_df.to_numpy())
    

def bbands_indicator(data):
    bbands = ta.bbands(close = data.Close.s,std = 1)

    return bbands.to_numpy().T[:3]

def macd_indicator(data):

    macd = ta.macd(close = data.Close.s )
    df = macd.iloc[:,[0,2]]
    return df.to_numpy()



class BBands(Strategy):

    def init(self):
        self.bbands = self.I(bbands_indicator,self.data)
        

    def next(self):
        
        lower_band = self.bbands[0]
        upper_band = self.bbands[2]

        if self.position:
            if self.data.Close[-1] > upper_band[-1]:
                self.position.close()
        else:
            if self.data.Close[-1] < lower_band[-1]:
                self.buy()


class MACD(Strategy):

    a = -1
    b = -1
    c = -1
    d = -1

    def init(self):
        self.macd = self.I(macd_indicator,self.data)

    def next(self):
        
        macd_line = self.macd[0]
        macd_signal = self.macd[1]

        if self.position:
            if macd_line[self.a] < macd_signal[self.b]:
                self.position.close()
        else:
            if macd_line[self.c] > macd_signal[self.d] :
                self.buy()


def ema_indicator(data):
    # open high low close data
    ema_12 = ta.ema(close = data.Close.s,length=12)
    ema_24 = ta.ema(close = data.Close.s,length=24)
    ema_55 = ta.ema(close = data.Close.s,length = 55)

    combined_df = pd.concat([ema_12, ema_24, ema_55], axis=1)

    return(combined_df.to_numpy())

class EMA(Strategy):

    def init(self):
        self.ema = self.I(ema_indicator,self.data)

    def next(self):
        ema_12 = self.ema[0]
        ema_24 = self.ema[1]
        ema_55 = self.ema[2]

        if self.position:
            if ema_12[-1] < ema_55[-1]:
                self.position.close()
        else:
            if (ema_12[-1] > ema_55[-1]) and (ema_12[-1] > ema_24[-1]):
                self.buy()


def vwma_indicator(data):

    vwma_13 = ta.vwma(close = data.Close.s , volume = data.Volume.s,length = 13)
    vwma_20 = ta.vwma(close = data.Close.s , volume = data.Volume.s,length = 20)
    df = pd.concat([vwma_13, vwma_20], axis=1)
    return df.to_numpy()


class VWMA(Strategy):

    a = -1
    b = -1

    def init(self):
        self.vwma = self.I(vwma_indicator,self.data)
        
    def next(self):

        vwma_13 = self.vwma[0]
        vwma_20 = self.vwma[1]
        
        if self.position:
            if vwma_13[self.a] > vwma_20[self.b] and self.data.Close[self.a] < vwma_13[self.b]:
                self.position.close()
        else:
            if vwma_13[self.a] > vwma_20[self.b] and self.data.Close[self.a] > vwma_13[self.b]:
                self.buy()


class CTIND(Strategy):

    def init(self):
        self.ema = self.I(ema_indicator,self.data)
        self.macd = self.I(macd_indicator,self.data)
    
    def next(self):
        ema_12 = self.ema[0]
        ema_24 = self.ema[1]
        ema_55 = self.ema[2]
        macd_line = self.macd[0]
        macd_signal = self.macd[1]

        if self.position:
            if ema_12[-1] < ema_55[-1] and macd_line[-1] < macd_signal[-1]:
                self.position.close()
        else:
            if macd_line[-1] > macd_signal[-1]:
                self.buy()





stocks_auto = ['TATAMOTORS.NS', 'MARUTI.NS', 'HEROMOTOCO.NS', 'BAJAJ-AUTO.NS', 'EICHERMOT.NS', 'ASHOKLEY.NS', 'TVSMOTOR.NS', 'M&M.NS', 'FORCEMOT.NS','BOSCHLTD.NS',
               'MOTHERSON.NS','CUMMINSIND.NS','UNOMINDA.NS','SCHAEFFLER.NS','ASHOKLEY.NS','EXIDEIND.NS','APOLLOTYRE.NS','TIMKEN.NS','JBMA.NS','CASTROLIND.NS']


stocks_bank = ['ICICIBANK.NS', 'HDFCBANK.NS', 'AXISBANK.NS', 'KOTAKBANK.NS', 'SBIN.NS', 'BANKBARODA.NS', 'PNB.NS', 'INDUSINDBK.NS', 'BANDHANBNK.NS', 'IDFCFIRSTB.NS',
                'UNIONBANK.NS','CANBK.NS','IDBI.NS','YESBANK.NS','CENTRALBK.NS','RBLBANK.NS','KARURVYSYA.NS','FEDERALBNK.NS','MAHABANK.NS','IOB.NS']

stocks_fmcg = ['HINDUNILVR.NS', 'NESTLEIND.NS', 'VBL.NS', 'GODREJCP.NS', 'BRITANNIA.NS', 'ITC.NS', 'COLPAL.NS', 'DABUR.NS', 'MARICO.NS', 'GLAXO.NS','JUBLFOOD.NS',
                'GILLETTE.NS','GODFRYPHLP.NS','JYOTHYLAB.NS','ZYDUSWELL.NS','ORIENTELEC.NS','HNDFDS.NS','SAFARI.NS','VIPIND.NS','BAJAJCON.NS']


stocks_finance = ['BAJFINANCE.NS','BAJAJFINSV.NS','IRFC.NS','PFC.NS','CHOLAFIN.NS','SHRIRAMFIN.NS','BAJAJHLDNG.NS','CHOLAHLDNG.NS','HDFCAMC.NS','SBICARD.NS',
                  'MUTHOOTFIN.NS','SUNDARAM.NS','L&TFH.NS','HUDCO.NS','LICHSGFIN.NS','MFSL.NS','TATAINVEST.NS','MOTILALOFS.NS','ISEC.NS','ANGELONE.NS']

stocks_healthcare = ['SUNPHARMA.NS','CIPLA.NS','DRREDDY.NS','DIVISLAB.NS','MANKIND.NS','ZYDUSLIFE.NS','APOLLOHOSP.NS','TORNTPHARM.NS','MAXHEALTH.NS','LUPIN.NS',
                     'AUROPHARMA.NS','ABBOTINDIA.NS','ALKEM.NS','IPCALAB.NS','FORTIS.NS','BIOCON.NS','GLAND.NS','GLENMARK.NS','SYNGENE.NS','AJANTPHARM.NS']


stocks_power = ['NTPC.NS','POWERGRID.NS','TATAPOWER.NS','ADANIPOWER.NS','JSWENERGY.NS','NHPC.NS','TORNTPOWER.NS','SJVN.NS','INDOWIND.NS','NLCINDIA.NS',
                'CESC.NS','IEX.NS','SWSOLAR.NS','RPOWER.NS','INDIGRID.NS','INOXWIND.NS','NAVA.NS','PTC.NS','RTNINDIA.NS','KIRLOSIND.NS']


stocks_it = ['TCS.NS','INFY.NS','HCLTECH.NS','WIPRO.NS','ZOMATO.NS','LTIM.NS','TECHM.NS','IRCTC.NS','OFSS.NS','PERSISTENT.NS',
             'TATAELXSI.NS','MPHASIS.NS','KPITTECH.NS','COFORGE.NS','PAYTM.NS','CYIENT.NS','SONATSOFTW.NS','BSOFT.NS','AFFLE.NS','ZENSARTECH.NS']


stock_sector = [stocks_healthcare,stocks_power,stocks_auto,stocks_bank,stocks_finance,stocks_fmcg,stocks_it]
strats = [VWMA,MACD,EMA,RSI,CTIND]
avg_ret = 0
data_dict = {}


# for k in stock_sector:
data = {}
for i in stocks_bank:
    df = pdr.get_data_yahoo(i, start="2001-01-01", end="2024-01-01")
    stats_list = []
    for j in strats:
        bt = Backtest(df, j, cash=100_000)
        stats = bt.run()
        stats_list.append(stats['Return (Ann.) [%]'])

        data[i] = stats_list

    df_result = pd.DataFrame(data, index=strats)
    
df_result = df_result.T.reset_index()
df_result = df_result.set_index('index')
df_result.columns = ['VWMA','MACD','EMA','RSI','CTIND']
df_result.loc['Mean Volatility'] = df_result.iloc[:20].mean()
print(df_result)
del df_result  


